#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define el cout<<endl;
#define debug(x) cout<<#x<<": "<<x<<','

using namespace std;

struct neo
{
	string s="worst case\n";
};

struct bipm
{
	static const int N=1e6+10;
	vi g[N];
	int m[N];
	bool v[N];

	bool dfs(int x)
	{
		for(auto y:g[x])
		{
			if(v[y])
				continue;
			v[y]=1;
			if(m[y]==-1||dfs(m[y]))
			{
				m[y]=x;
				return 1;
			}
		}
		return 0;
	}

	int m_bpm(int p)
	{
		int ans=0;
		memset(m,-1,sizeof(m));
		for(int i=1;i<=p;i++)
		{
			memset(v,0,sizeof(v));
			ans+=dfs(i);
		}
		return ans;
	}
};

int q,w;
int a,b;
bipm bm;

signed main()
{
	cin>>q>>w;
	for(int i=0;i<w;i++)
	{
		cin>>a>>b;
		bm.g[a].push_back(b);
		bm.g[b].push_back(a);
	}
	if(q-bm.m_bpm(q)==0)
	{
		for(int i=1;i<=q;i++)
		{
			cout<<bm.m[i]<<endl;
		}
		return 0;
	}
	cout<<"Impossible\n";
	return 0;
}