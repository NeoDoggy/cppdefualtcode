#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define el cout<<endl;
#define debug(x) cout<<#x<<": "<<x<<','

using namespace std;
const int N=1e6+10;


struct neo
{
	string s="worst case\n";
};

int t;
int arr[N];
int dp[N];

int solve(int p)
{
	if(arr[0]!=1)
		return 0;
	for(int i=0;i<p;i++)
	{
		dp[1]=1;
		for(int j=1;j<=i;j++)
		{
			if(__gcd(arr[j],arr[j+1])>1)
			{
				dp[i]++;
			}
		}
		dp[i]=max(dp[i],dp[i-1]);
	}
	return dp[p-1];
}

signed main()
{
	cin>>t;
	while(t--)
	{
		int tmp;
		cin>>tmp;
		memset(arr,0,sizeof(arr));
		memset(dp,0,sizeof(dp));
		for(int i=0;i<tmp;i++)
		{
			cin>>arr[i];
		}
		cout<<solve(tmp)<<endl;
	}
	return 0;
}