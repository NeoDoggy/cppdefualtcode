#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define el cout<<endl;
#define debug(x) cout<<#x<<": "<<x<<','

using namespace std;

int findMinLength(string arr[], int n) 
{ 
    int min = INT_MAX; 

    for (int i=0;i<=n-1;i++) 
        if (arr[i].size()<min) 
            min = arr[i].size(); 
    return min; 
} 

bool allContainsPrefix(string arr[], int n, string str, int start, int end) 
{ 
    for (int i=0; i<=n-1; i++) 
        for (int j=start; j<=end; j++) 
            if (arr[i][j] != str[j]) 
                return 0; 
    return 1; 
} 

string commonPrefix(string arr[], int n) 
{ 
    int index = findMinLength(arr, n); 
    string prefix;

    int low = 0, high = index; 

    while (low <= high) 
    { 
        int mid = low+(high-low)/2; 

        if (allContainsPrefix (arr, n, arr[0], low, mid)) 
        { 
            prefix=prefix+arr[0].substr(low,mid-low+1); 
            low=mid+1; 
        } 
        else
            high=mid-1; 
    }
    return prefix; 
}

string upside(string s)
{
    string tmp="";
    for(int i=s.size()-1;i>=0;i--)
    {
        tmp+=s[i];
    }
    return tmp;
}

string str[3];
int ans;
int a,b;

signed main()
{
    ios_base::sync_with_stdio(0),cin.tie(0);
    cin>>a>>b;
    cin>>str[0]>>str[1];
    ans+=commonPrefix(str,2).size();
    str[0]=upside(str[0]);str[1]=upside(str[1]);
    ans+=commonPrefix(str,2).size();
    cout<<ans<<endl;
}
