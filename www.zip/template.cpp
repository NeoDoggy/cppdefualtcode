#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define el cout<<endl;
#define debug(x) cout<<#x<<": "<<x<<','

using namespace std;

struct neo
{
	string s="worst case\n";
};

signed main()
{


	return 0;
}